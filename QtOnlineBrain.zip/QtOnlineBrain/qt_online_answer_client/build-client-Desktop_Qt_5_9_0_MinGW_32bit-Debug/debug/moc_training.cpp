/****************************************************************************
** Meta object code from reading C++ file 'training.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../client/training.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'training.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_training_t {
    QByteArrayData data[21];
    char stringdata0[480];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_training_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_training_t qt_meta_stringdata_training = {
    {
QT_MOC_LITERAL(0, 0, 8), // "training"
QT_MOC_LITERAL(1, 9, 23), // "on_singleButton_clicked"
QT_MOC_LITERAL(2, 33, 0), // ""
QT_MOC_LITERAL(3, 34, 22), // "on_single_back_clicked"
QT_MOC_LITERAL(4, 57, 23), // "on_single_start_clicked"
QT_MOC_LITERAL(5, 81, 21), // "receiveSingleQuestion"
QT_MOC_LITERAL(6, 103, 4), // "json"
QT_MOC_LITERAL(7, 108, 34), // "on_single_SelectButton_one_cl..."
QT_MOC_LITERAL(8, 143, 34), // "on_single_SelectButton_two_cl..."
QT_MOC_LITERAL(9, 178, 36), // "on_single_SelectButton_three_..."
QT_MOC_LITERAL(10, 215, 35), // "on_single_SelectButton_four_c..."
QT_MOC_LITERAL(11, 251, 14), // "singleTimerOut"
QT_MOC_LITERAL(12, 266, 35), // "on_singnal_score_backButton_c..."
QT_MOC_LITERAL(13, 302, 21), // "on_rankButton_clicked"
QT_MOC_LITERAL(14, 324, 4), // "Rank"
QT_MOC_LITERAL(15, 329, 12), // "RankTimerOut"
QT_MOC_LITERAL(16, 342, 28), // "on_rankSelectButton1_clicked"
QT_MOC_LITERAL(17, 371, 28), // "on_rankSelectButton2_clicked"
QT_MOC_LITERAL(18, 400, 28), // "on_rankSelectButton3_clicked"
QT_MOC_LITERAL(19, 429, 28), // "on_rankSelectButton4_clicked"
QT_MOC_LITERAL(20, 458, 21) // "on_pushButton_clicked"

    },
    "training\0on_singleButton_clicked\0\0"
    "on_single_back_clicked\0on_single_start_clicked\0"
    "receiveSingleQuestion\0json\0"
    "on_single_SelectButton_one_clicked\0"
    "on_single_SelectButton_two_clicked\0"
    "on_single_SelectButton_three_clicked\0"
    "on_single_SelectButton_four_clicked\0"
    "singleTimerOut\0on_singnal_score_backButton_clicked\0"
    "on_rankButton_clicked\0Rank\0RankTimerOut\0"
    "on_rankSelectButton1_clicked\0"
    "on_rankSelectButton2_clicked\0"
    "on_rankSelectButton3_clicked\0"
    "on_rankSelectButton4_clicked\0"
    "on_pushButton_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_training[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      18,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  104,    2, 0x08 /* Private */,
       3,    0,  105,    2, 0x08 /* Private */,
       4,    0,  106,    2, 0x08 /* Private */,
       5,    1,  107,    2, 0x08 /* Private */,
       7,    0,  110,    2, 0x08 /* Private */,
       8,    0,  111,    2, 0x08 /* Private */,
       9,    0,  112,    2, 0x08 /* Private */,
      10,    0,  113,    2, 0x08 /* Private */,
      11,    0,  114,    2, 0x08 /* Private */,
      12,    0,  115,    2, 0x08 /* Private */,
      13,    0,  116,    2, 0x08 /* Private */,
      14,    1,  117,    2, 0x08 /* Private */,
      15,    0,  120,    2, 0x08 /* Private */,
      16,    0,  121,    2, 0x08 /* Private */,
      17,    0,  122,    2, 0x08 /* Private */,
      18,    0,  123,    2, 0x08 /* Private */,
      19,    0,  124,    2, 0x08 /* Private */,
      20,    0,  125,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QJsonObject,    6,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QJsonObject,    6,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void training::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        training *_t = static_cast<training *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_singleButton_clicked(); break;
        case 1: _t->on_single_back_clicked(); break;
        case 2: _t->on_single_start_clicked(); break;
        case 3: _t->receiveSingleQuestion((*reinterpret_cast< QJsonObject(*)>(_a[1]))); break;
        case 4: _t->on_single_SelectButton_one_clicked(); break;
        case 5: _t->on_single_SelectButton_two_clicked(); break;
        case 6: _t->on_single_SelectButton_three_clicked(); break;
        case 7: _t->on_single_SelectButton_four_clicked(); break;
        case 8: _t->singleTimerOut(); break;
        case 9: _t->on_singnal_score_backButton_clicked(); break;
        case 10: _t->on_rankButton_clicked(); break;
        case 11: _t->Rank((*reinterpret_cast< QJsonObject(*)>(_a[1]))); break;
        case 12: _t->RankTimerOut(); break;
        case 13: _t->on_rankSelectButton1_clicked(); break;
        case 14: _t->on_rankSelectButton2_clicked(); break;
        case 15: _t->on_rankSelectButton3_clicked(); break;
        case 16: _t->on_rankSelectButton4_clicked(); break;
        case 17: _t->on_pushButton_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject training::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_training.data,
      qt_meta_data_training,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *training::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *training::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_training.stringdata0))
        return static_cast<void*>(const_cast< training*>(this));
    return QDialog::qt_metacast(_clname);
}

int training::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 18)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 18;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 18)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 18;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
